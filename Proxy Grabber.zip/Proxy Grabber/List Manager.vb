﻿Imports System.ComponentModel

Public Class List_Manager
    Public Function save()
        If Label1.Text = "No File Selected" Then
            Label1.Text = System.Environment.GetEnvironmentVariable("dekstop") & System.Text.RegularExpressions.Regex.Replace(Now.ToString, "[^A-Za-z0-9]", "") & ".txt"
        End If
        If MsgBox("Do you want to continue?", MsgBoxStyle.OkCancel) = 1 Then
            Using SW As New IO.StreamWriter(Label1.Text, False)
                For Each itm As Object In ListBox1.Items
                    SW.WriteLine(itm)
                Next
            End Using
        End If
    End Function
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim iProxy As Object
        iProxy = Trim(TextBox1.Text)
        If iProxy <> "" Then
            If Main.checkRight(iProxy) Then
                ListBox1.Items.Add(iProxy)
                TextBox1.Clear()
            Else
                MsgBox("Wrong Input." & vbNewLine & "The proxy should be look like:" & vbNewLine & "XXX.XXX.XXX.XXX : XXXX" & vbNewLine & "Proxy:Port" & vbNewLine & "e.g. 172.154.7.65 : 80 ")
            End If
        Else
            MsgBox("Don't live it blank.")
        End If
    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        OpenFileDialog1.ShowDialog()
    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        Label1.Text = OpenFileDialog1.FileName
        ListBox1.Items.AddRange(IO.File.ReadAllLines(Label1.Text))
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        save()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        SaveFileDialog1.ShowDialog()
    End Sub

    Private Sub SaveFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk
        Label1.Text = SaveFileDialog1.FileName
        save()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If ListBox1.SelectedIndex >= 0 And ListBox1.SelectedIndex <ListBox1.Items.Count() Then
            ListBox1.Items.Remove(ListBox1.SelectedItem)
            Label2.Text = ListBox1.Items.Count()
        Else
            MsgBox("Please, select a Value")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ListBox1.Items.Clear()
        Label1.Text = ""
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Button9.Visible = False
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Button10.Visible = False
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Button11.Visible = False
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Button12.Visible = False
    End Sub

    Private Sub List_Manager_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Main.ListBox1.Items.Clear()
        Main.ListBox1.Items.AddRange(ListBox1.Items)
            Main.Visible = True
    End Sub

    Private Sub List_Manager_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.Items.AddRange(Main.ListBox1.Items)
    End Sub
End Class