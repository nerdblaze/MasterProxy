﻿Imports System.Text.RegularExpressions
Imports Microsoft.Win32
Imports System.Net.NetworkInformation
Imports System.Net
Imports System.Management
Imports System.Diagnostics.Process

Public Class Main
    Dim regKey2, Reg24Online As RegistryKey
    Dim TimeLeft, AdapterIndex, TimeText, i, Low, High As Integer
    Dim Process24, Processcmd As New Process
    Dim EthernetId, DNS As String
    Dim IPAddress, Gateway As String()
    Private webAddress As Object
    Declare Function SendARP Lib "iphlpapi.dll" Alias "SendARP" (ByVal DestIP As Integer, ByVal SrcIP As Integer, ByVal pMacAddr() As Byte, ByRef PhyAddrLen As Integer) As Integer
    Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long
    Const SW_SHOWNORMAL = 1
    Private Function GetMACAddress(ByVal Adapter As String) As String
        Dim mc As System.Management.ManagementClass
        Dim mo As ManagementObject
        mc = New ManagementClass("Win32_NetworkAdapterConfiguration")
        Dim moc As ManagementObjectCollection = mc.GetInstances()
        For Each mo In moc
            If mo.Item("IPEnabled") = True Then
                Dim strAdapter As String
                strAdapter = mo.Item("Caption").ToString().Substring(11)
                If strAdapter = Adapter Then
                    Return mo.Item("MacAddress").ToString()
                End If
            End If
        Next
    End Function
    Private Sub FillNetworkAdapters()
        Dim mc As System.Management.ManagementClass
        Dim mo As ManagementObject
        mc = New ManagementClass("Win32_NetworkAdapterConfiguration")
        Dim moc As ManagementObjectCollection = mc.GetInstances()
        For Each mo In moc
            If mo.Item("IPEnabled") = True Then
                Dim strAdapter As String
                strAdapter = mo.Item("Caption").ToString().Substring(11)

                Combo_network.Items.Add(strAdapter.Replace(":", "-"))
            End If
        Next
    End Sub
    Public Function GetMacNetwork(ByVal ipAddr As String) As String
        Dim macAddress As String = String.Empty
        Try
            Dim destIP As Net.IPAddress = Net.IPAddress.Parse(ipAddr)
            Dim IP() As Byte = destIP.GetAddressBytes()
            Dim IPInt As Integer = BitConverter.ToInt32(IP, 0)
            Dim mac() As Byte = New Byte(5) {}
            SendARP(IPInt, 0, mac, mac.Length)
            macAddress = BitConverter.ToString(mac, 0, mac.Length)
        Catch ex As Exception
            Debug.Write(ex.Message)
        End Try
        Return macAddress
    End Function
    Public Function checkRight(readcode As Object)
        Dim checker As New Regex("[0-9].{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}:[0-9]{1,5}")
        Return checker.IsMatch(readcode)
    End Function
    Public Function CheckConnectionStatus()
        ToolStripStatusLabel2.Text = "Connecting..."
        Dim AddressText As Object
        Dim output As PingReply
        Dim pinger As New Ping
        Try
            AddressText = "www.google.com"
            output = pinger.Send(AddressText)
            If output.Status.ToString = "Success" Then
                AddressText = "www.facebook.com"
                output = pinger.Send(AddressText)
                If output.Status.ToString = "Success" Then
                    AddressText = "www.tracemyip.org"
                    output = pinger.Send(AddressText)
                    If output.Status.ToString = "Success" Then
                        AddressText = "www.youtube.com"
                        output = pinger.Send(AddressText)
                        If output.Status.ToString = "Success" Then
                            ToolStripStatusLabel2.Text = "Connection is OKay!"
                            Return True
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            ToolStripStatusLabel2.Text = "Could not Connect to " & AddressText
            Return False
        End Try
    End Function
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            If IsNothing(ListBox1.SelectedItem) Then
                MsgBox("Please, select one proxy")
                Return
            Else
                Dim regKey1 As RegistryKey
                regKey1 = Registry.CurrentUser.CreateSubKey("Software\Microsoft\Windows\CurrentVersion\Internet Settings", RegistryKeyPermissionCheck.Default)
                regKey1.SetValue("ProxyEnable", True, RegistryValueKind.DWord)
                regKey1.SetValue("ProxyServer", ListBox1.SelectedItem, RegistryValueKind.String)
                regKey1.Close()
                regKey2 = Registry.CurrentUser.CreateSubKey("Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap", RegistryKeyPermissionCheck.Default)
                regKey2.SetValue("Autodetect", False, RegistryValueKind.DWord)
                regKey2.Close()
                If CheckConnectionStatus() Then
                    Timer1.Enabled = True
                    TimeLeft = 10
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub

    Public Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim regKey As RegistryKey
        regKey = Registry.CurrentUser.CreateSubKey("Software\Microsoft\Windows\CurrentVersion\Internet Settings", RegistryKeyPermissionCheck.Default)
        regKey.SetValue("ProxyEnable", False, RegistryValueKind.DWord)
        regKey.Close()
        regKey = Registry.CurrentUser.CreateSubKey("Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap", RegistryKeyPermissionCheck.Default)
        regKey.SetValue("Autodetect", True, RegistryValueKind.DWord)
        regKey.Close()
        ToolStripStatusLabel2.Text = "Disconnected"
        Timer1.Enabled = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If TimeLeft > 0 Then
            TimeLeft -= 1
        Else
            Try
                If CheckConnectionStatus() Then
                    ToolStripStatusLabel2.Text = "Connected"
                Else
                    ToolStripStatusLabel2.Text = "Connection Failed. Try, another proxy"
                End If
            Catch ex As Exception
            End Try
        End If
        Timer1.Enabled = False
    End Sub
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        ListBox1.Items.Clear()
        Label2.Text = "0"
        CustomToolStripMenuItem.Checked = False
        DefaultToolStripMenuItem.Checked = False
    End Sub

    Private Sub RestartToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RestartToolStripMenuItem.Click
        Process.Start("Master Proxy.exe")
        Visible = False
        End
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        ToolStripStatusLabel2.Text = "Exiting..."
        Button3.PerformClick()
        Visible = False
        Reg24Online.Close()
        Try
            Process24.Kill()
        Catch ex As Exception
        End Try
        Threading.Thread.Sleep(5000)
        End
    End Sub
    Private Sub BypassLocalToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BypassLocalToolStripMenuItem.Click
        regKey2 = Registry.CurrentUser.CreateSubKey("Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap", RegistryKeyPermissionCheck.Default)
        If BypassLocalToolStripMenuItem.Checked Then
            BypassLocalToolStripMenuItem.Checked = False
        Else
            BypassLocalToolStripMenuItem.Checked = True
        End If
        If BypassLocalToolStripMenuItem.Checked <> 0 Then
            regKey2.SetValue("ProxyByPass", True, RegistryValueKind.DWord)
        Else
            regKey2.SetValue("ProxyByPass", False, RegistryValueKind.DWord)
        End If
        regKey2.Close()
    End Sub

    Private Sub DefaultToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DefaultToolStripMenuItem.Click
        CustomToolStripMenuItem.Checked = False
        DefaultToolStripMenuItem.Checked = True
        Call Button7.PerformClick()
        ListBox1.Items.AddRange(IO.File.ReadAllLines("Default.txt"))
        Label2.Text = ListBox1.Items.Count()
    End Sub

    Private Sub CustomToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomToolStripMenuItem.Click
        DefaultToolStripMenuItem.Checked = False
        CustomToolStripMenuItem.Checked = True
        Call Button7.PerformClick()
        'From File
        ListBox1.Items.AddRange(IO.File.ReadAllLines("Custom.txt"))
        Label2.Text = ListBox1.Items.Count()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        AboutBox1.Show()
    End Sub


    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim Request As HttpWebRequest
        Dim Response As HttpWebResponse
        Dim Reader As IO.StreamReader
        Dim Readcode As String
        Dim Right As MatchCollection
        If CheckConnectionStatus() Then
            'Download Proxies from the web
            ListBox2.Items.AddRange(IO.File.ReadAllLines("Web.txt"))
            For Each webAddress As Object In ListBox2.Items
                Try
                    ToolStripStatusLabel2.Text = "Loading Proxies... "
                    Request = HttpWebRequest.Create(webAddress)
                    Response = Request.GetResponse
                    Reader = New IO.StreamReader(Response.GetResponseStream)
                    Readcode = Reader.ReadToEnd
                    Dim checker As New Regex("[0-9].{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}:[0-9]{1,5}")
                    Right = checker.Matches(Readcode)
                    For Each itemcode As Match In Right
                        ListBox1.Items.Add(itemcode)
                    Next
                Catch ex As Exception
                    ToolStripStatusLabel2.Text = "Failed to connect with..." & webAddress
                End Try
            Next
            Label2.Text = ListBox1.Items.Count()
            ToolStripStatusLabel2.Text = "Locked and Loaded "
        Else
            MsgBox("Check your Internet Connection")
            ToolStripStatusLabel2.Text = "No internet connection "
        End If
    End Sub

    Private Sub Main_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        ExitToolStripMenuItem.PerformClick()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        CheckConnectionStatus()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        ListBox3.Items.Clear()
        Dim IPadrs As Object
        Low = Val(TextBox4.Text)
        High = Val(TextBox5.Text)
        Try
            For i = Low To High
                IPadrs = TextBox1.Text & "." & TextBox2.Text & "." & TextBox3.Text & "." & i
                If My.Computer.Network.Ping(IPadrs) Then
                    ListBox3.Items.Add(IPadrs & " Alive " & GetMacNetwork(IPadrs))
                    'Else
                    'ListBox1.Items.Add(IPadrs & vbTab & "Dead")
                End If
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        TextBox5.Text = TextBox1.Text
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        TextBox1.Text = TextBox5.Text
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        TextBox6.Text = TextBox2.Text
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Try
            ToolStripTextBox7.Text = Trim(ListBox3.SelectedItem).Substring(0, ListBox3.SelectedItem.ToString.IndexOf(" "))
            ToolStripTextBox4.Text = Trim(ListBox3.SelectedItem).Replace("-", "").Substring(ListBox3.SelectedItem.ToString.IndexOf("Alive ") + 6)
        Catch ex As Exception
        End Try
        'Get Addresses
        Dim DNS12, MAC As String
        DNS12 = ToolStripTextBox5.Text & "," & ToolStripTextBox8.Text
        MAC = ToolStripTextBox4.Text

        Dim ChangeReg As RegistryKey = Registry.LocalMachine.CreateSubKey("SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\" & EthernetId, RegistryKeyPermissionCheck.ReadWriteSubTree)
        ChangeReg.SetValue("IPAddress", New String() {ToolStripTextBox7.Text}, RegistryValueKind.MultiString)
        ChangeReg.SetValue("DefaultGateway", New String() {ToolStripTextBox6.Text}, RegistryValueKind.MultiString)
        ChangeReg.SetValue("NameServer", DNS12, RegistryValueKind.String)
        My.Computer.Registry.SetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}\" & AdapterIndex.ToString("0000"), "NetworkAddress", MAC, RegistryValueKind.String)
        Dim processgo As New Process
        processgo.StartInfo.CreateNoWindow = True
        processgo = Start("cmd", "/c wmic path win32_networkadapter where index=0 Call disable")
        Threading.Thread.Sleep(5000)
        processgo = Process.Start("cmd", "/c wmic path win32_networkadapter where index=0 Call enable")
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        TextBox2.Text = TextBox6.Text
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        TextBox7.Text = TextBox3.Text
    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged
        TextBox3.Text = TextBox7.Text
    End Sub

    Private Sub WhatsNewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WhatsNewToolStripMenuItem.Click
        Process.Start("Notepad.exe", "Release_log.txt")
    End Sub

    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reg24Online = Registry.CurrentUser.CreateSubKey("Software\eLitecore\Cyberoam\24Online\Authentication Client\Preferences", RegistryKeyPermissionCheck.Default)
        ToolStripTextBox1.Text = Reg24Online.GetValue("User")
        ToolStripTextBox2.Text = Reg24Online.GetValue("Password")
        ToolStripTextBox3.Text = Reg24Online.GetValue("Server")
        'Get Adapter Id
        EthernetId = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkCards\1", "ServiceName", Nothing)
        'Get IpAddress from registry
        IPAddress = CType(My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\" & EthernetId, "IPAddress", Nothing), String())
        For indexIP As Integer = 0 To UBound(IPAddress)
            ToolStripTextBox7.Text = ToolStripTextBox7.Text & IPAddress(indexIP)
        Next
        'Get Default Gateway
        ToolStripTextBox6.Text = NetworkInterface.GetAllNetworkInterfaces(0).GetIPProperties().GatewayAddresses.Item(0).Address.ToString()
        'Get DNS Server
        DNS = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\" & EthernetId, "NameServer", Nothing)
        ToolStripTextBox5.Text = DNS.Substring(0, DNS.IndexOf(","))
        ToolStripTextBox8.Text = DNS.Substring(DNS.IndexOf(",") + 1)
        'Get MacAddress
        FillNetworkAdapters()
        AdapterIndex = 0
    End Sub

    Private Sub ListManagerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListManagerToolStripMenuItem.Click
        Visible = False
        List_Manager.Show()
    End Sub

    Private Sub LoginToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles LoginToolStripMenuItem1.Click
        Reg24Online.SetValue("User", Trim(ToolStripTextBox1.Text), RegistryValueKind.String)
        Reg24Online.SetValue("Password", Trim(ToolStripTextBox2.Text), RegistryValueKind.String)
        Reg24Online.SetValue("Server", Trim(ToolStripTextBox3.Text), RegistryValueKind.String)
        Reg24Online.SetValue("AutoLogin", 1, RegistryValueKind.DWord)
        Reg24Online.SetValue("SavePassword", 1, RegistryValueKind.DWord)
        Reg24Online.SetValue("FirstTime", 0, RegistryValueKind.DWord)
        Try
            Process24 = Process.Start("CyberoamClient.exe")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Combo_network_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combo_network.SelectedIndexChanged
        ToolStripTextBox4.Text = GetMACAddress(Combo_network.SelectedItem.ToString)
    End Sub
End Class
